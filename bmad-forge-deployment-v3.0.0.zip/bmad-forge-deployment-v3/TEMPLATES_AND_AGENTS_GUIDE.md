# BMAD Forge Templates and Agents

## Overview

This deployment package includes **15 document templates** and **15 AI agent prompts** to accelerate product development and documentation workflows.

---

## 📝 Document Templates (15 files)

Professional markdown templates for common product and technical documentation needs.

### Product Management Templates

| Template | Purpose | Use Case |
|----------|---------|----------|
| `PRD_template.md` | Product Requirements Document | Define product requirements and specifications |
| `ProductStrategy_template.md` | Product Strategy | Define product vision, goals, and market positioning |
| `ProductRoadmap_template.md` | Product Roadmap | Plan product releases and feature timelines |
| `ProductBacklog_template.md` | Product Backlog | Manage and prioritize product features |
| `ReleasePlan_template.md` | Release Planning | Plan product releases and deployment |
| `MVPFeatureList_template.md` | MVP Feature List | Define minimum viable product features |
| `FeatureRequestDocument_template.md` | Feature Requests | Document and track feature requests |

### UX/Design Templates

| Template | Purpose | Use Case |
|----------|---------|----------|
| `DesignSpec_template.md` | Design Specification | Define UI/UX design requirements |
| `CustomerJourneyMap_template.md` | Customer Journey Map | Map user experience and touchpoints |
| `UserStoryMapping_template.md` | User Story Mapping | Organize user stories and features |
| `UsabilityTestPlan_template.md` | Usability Testing | Plan and document usability tests |

### Technical Templates

| Template | Purpose | Use Case |
|----------|---------|----------|
| `technicaldesigndocument_template.md` | Technical Design Doc | Document system architecture and design |
| `APIDocumentation_template.md` | API Documentation | Document API endpoints and usage |
| `ProductSecurityAssessment_template.md` | Security Assessment | Assess product security requirements |

### Analytics Templates

| Template | Purpose | Use Case |
|----------|---------|----------|
| `KPIDashboard_template.md` | KPI Dashboard | Track key performance indicators |

---

## 🤖 AI Agent Prompts (15 files)

Pre-configured AI agent prompts for different development roles and tasks.

### Role-Based Agents

| Agent | Role | Capabilities |
|-------|------|--------------|
| `productmanager_prompt.md` | Product Manager | Product strategy, roadmaps, PRDs |
| `architect_prompt.md` | Solutions Architect | System design, architecture decisions |
| `frontend_prompt.md` | Frontend Developer | UI/UX implementation, React, Vue |
| `backend_prompt.md` | Backend Developer | API development, databases, services |
| `uxdesigner_prompt.md` | UX Designer | User research, wireframes, prototypes |
| `qa_prompt.md` | QA Engineer | Test planning, quality assurance |
| `devops_prompt.md` | DevOps Engineer | CI/CD, infrastructure, deployment |
| `security_prompt.md` | Security Engineer | Security assessment, threat modeling |

### Task-Specific Agents

| Agent | Task | Purpose |
|-------|------|---------|
| `prd_generate_epic_prompt.md` | Epic Generation | Generate epics from PRD |
| `generate_epics.md` | Epic Generator | Create detailed epics |
| `selfdocagent_prompt.md` | Self-Documentation | Auto-generate documentation |
| `selfdocslashcommand_prompt.md` | Doc Slash Command | Quick documentation generation |

### Workflow Agents

| Agent | Phase | Focus |
|-------|-------|-------|
| `phase1.md` | Phase 1 | Discovery and planning |
| `phase2.md` | Phase 2 | Design and development |
| `phase3.md` | Phase 3 | Testing and deployment |

---

## 🚀 How to Use

### Using Templates

1. **Browse Templates**
   ```bash
   cd templates/
   ls -la
   ```

2. **Copy Template for Your Project**
   ```bash
   cp templates/PRD_template.md my-project/PRD.md
   ```

3. **Fill in Template Sections**
   - Open the template in your editor
   - Replace placeholder text with your content
   - Follow the structure provided

4. **Example: Creating a PRD**
   ```bash
   # Copy template
   cp templates/PRD_template.md docs/MyProduct_PRD.md
   
   # Edit with your favorite editor
   code docs/MyProduct_PRD.md
   ```

### Using AI Agent Prompts

1. **Choose the Right Agent**
   - Identify your task (e.g., creating a PRD)
   - Select appropriate agent (e.g., `productmanager_prompt.md`)

2. **Load Agent Prompt**
   ```bash
   cat agents/productmanager_prompt.md
   ```

3. **Use with AI Assistant**
   - Copy the agent prompt
   - Paste into your AI assistant (Claude, ChatGPT, etc.)
   - Provide your specific requirements
   - Let the agent guide the process

4. **Example: Generate PRD with AI**
   ```
   1. Read: agents/productmanager_prompt.md
   2. Copy the prompt to Claude
   3. Provide: "Create a PRD for a mobile expense tracking app"
   4. Agent will guide you through PRD creation
   ```

### Combining Templates and Agents

**Best Practice Workflow:**

1. **Choose Template** (what document you need)
2. **Select Agent** (who can help create it)
3. **Generate Content** (AI fills in the template)
4. **Review & Refine** (human oversight)

**Example: Creating a Technical Design Document**

```bash
# 1. Copy template
cp templates/technicaldesigndocument_template.md docs/TDD_MyFeature.md

# 2. Use architect agent
cat agents/architect_prompt.md

# 3. In Claude/AI:
# "Acting as the Solutions Architect agent, help me fill in this
#  technical design document template for a real-time notification system"

# 4. AI provides structured content following template
# 5. Review and customize
```

---

## 📂 Integration with BMAD Forge

### Option 1: Import as Document Templates

1. **Access Django Admin**
   ```
   http://localhost:8000/admin
   ```

2. **Create Template**
   - Go to "Document Templates"
   - Click "Add Document Template"
   - Copy content from `templates/*.md`
   - Configure variables
   - Save

3. **Generate Documents**
   - Use BMAD Forge wizard
   - Select template
   - Fill in variables
   - Generate document

### Option 2: Use as Reference

Keep templates in the `templates/` folder as reference:
- Developers can copy and customize
- Teams can standardize documentation
- CI/CD can auto-generate from templates

### Option 3: Automate with Agents

Create scripts that use agent prompts:

```python
# Example: Auto-generate PRD using agent
def generate_prd(product_idea):
    agent_prompt = read_file('agents/productmanager_prompt.md')
    template = read_file('templates/PRD_template.md')
    
    # Use AI API with agent + template
    prd = ai_api.generate(
        system_prompt=agent_prompt,
        user_input=f"Create PRD for: {product_idea}",
        template=template
    )
    
    return prd
```

---

## 🎯 Use Cases

### Scenario 1: New Product Launch

```
1. Product Strategy → templates/ProductStrategy_template.md
2. Use Agent → agents/productmanager_prompt.md
3. Create PRD → templates/PRD_template.md
4. Design Spec → templates/DesignSpec_template.md
5. Technical Design → templates/technicaldesigndocument_template.md
6. Release Plan → templates/ReleasePlan_template.md
```

### Scenario 2: Feature Development

```
1. Feature Request → templates/FeatureRequestDocument_template.md
2. Use Agent → agents/prd_generate_epic_prompt.md
3. Generate Epics → agents/generate_epics.md
4. User Stories → templates/UserStoryMapping_template.md
5. API Docs → templates/APIDocumentation_template.md
6. Test Plan → templates/UsabilityTestPlan_template.md
```

### Scenario 3: Security Review

```
1. Use Agent → agents/security_prompt.md
2. Assessment → templates/ProductSecurityAssessment_template.md
3. Generate Report
```

---

## 🔄 Workflow Phases

The package includes phase-based workflow guides:

### Phase 1: Discovery & Planning
- **Agent**: `agents/phase1.md`
- **Templates**: 
  - `ProductStrategy_template.md`
  - `CustomerJourneyMap_template.md`
  - `ProductRoadmap_template.md`

### Phase 2: Design & Development
- **Agent**: `agents/phase2.md`
- **Templates**:
  - `DesignSpec_template.md`
  - `technicaldesigndocument_template.md`
  - `APIDocumentation_template.md`

### Phase 3: Testing & Deployment
- **Agent**: `agents/phase3.md`
- **Templates**:
  - `UsabilityTestPlan_template.md`
  - `ReleasePlan_template.md`
  - `KPIDashboard_template.md`

---

## 📋 Quick Reference

### Most Common Templates

1. **PRD** - Start here for new products/features
2. **Technical Design** - For engineering specifications
3. **API Documentation** - For backend APIs
4. **Release Plan** - For deployment planning
5. **Product Roadmap** - For long-term planning

### Most Common Agents

1. **Product Manager** - Product-related tasks
2. **Architect** - System design decisions
3. **PRD Epic Generator** - Break down requirements
4. **Frontend/Backend** - Development guidance
5. **Security** - Security assessments

---

## 🛠️ Customization

### Modifying Templates

Templates are markdown files - easy to customize:

```bash
# Edit template
nano templates/PRD_template.md

# Add your company branding
# Add/remove sections
# Customize fields
```

### Modifying Agents

Agent prompts can be tuned for your needs:

```bash
# Edit agent
nano agents/productmanager_prompt.md

# Adjust:
# - Tone and style
# - Specific frameworks (e.g., SCRUM vs Kanban)
# - Company-specific processes
# - Industry terminology
```

---

## 📖 Template Format

All templates follow this structure:

```markdown
# [Document Title]

## Document Information
- **Author**: [Name]
- **Date**: [Date]
- **Version**: [Version]

## [Section 1]
[Content guidelines and placeholders]

## [Section 2]
[Content guidelines and placeholders]

---

**Template Version**: 1.0
```

---

## 🤝 Contributing

To add your own templates or agents:

1. **Create Template**
   ```bash
   cp templates/PRD_template.md templates/MyTemplate_template.md
   ```

2. **Follow Naming Convention**
   - Templates: `[DocumentType]_template.md`
   - Agents: `[role/task]_prompt.md`

3. **Document Usage**
   - Add to this README
   - Include example use case

---

## 📚 Additional Resources

### Template Best Practices

- **Keep it Simple**: Don't over-complicate templates
- **Provide Examples**: Include sample content where helpful
- **Stay Flexible**: Allow customization
- **Version Control**: Track template changes

### Agent Prompt Best Practices

- **Clear Role Definition**: Define the agent's expertise
- **Specific Instructions**: Provide clear guidelines
- **Context Awareness**: Include domain knowledge
- **Output Format**: Specify expected output structure

---

## 🆘 Support

For help using templates and agents:

1. **Template Issues**: Check template comments for guidance
2. **Agent Issues**: Review agent prompt for instructions
3. **Integration**: See BMAD Forge documentation
4. **Custom Needs**: Modify templates/agents as needed

---

## 📊 Statistics

**Package Contains:**
- 15 Document Templates
- 15 AI Agent Prompts
- 30 Total Files
- Covering 8 Roles
- Supporting 3 Development Phases

**Coverage:**
- Product Management: 7 templates
- UX/Design: 4 templates
- Technical: 3 templates
- Analytics: 1 template
- Development: 8 agents
- Management: 4 agents
- Process: 3 workflow guides

---

**Document Version**: 1.0  
**Last Updated**: February 5, 2026  
**Package**: BMAD Forge v3.0.0
