# BMAD Forge Quick Start Guide

## 5-Minute Deployment

### Step 1: Extract Package
Extract to: `C:\BMAD_FORGE_DEPLOYMENT_PACKAGE_v3.0`

### Step 2: Run Deployment
Open PowerShell as Administrator:
```powershell
cd C:\BMAD_FORGE_DEPLOYMENT_PACKAGE_v3.0\scripts
.\deploy.ps1 -CreateProject
```

### Step 3: Test Installation
```powershell
cd C:\inetpub\bmad-forge
.\test-deployment.ps1
```

### Step 4: Create Admin User
```powershell
cd C:\inetpub\bmad-forge\webapp
C:\inetpub\bmad-forge\venv\Scripts\python.exe manage.py createsuperuser
```

### Step 5: Start Server
```powershell
C:\inetpub\bmad-forge\venv\Scripts\python.exe manage.py runserver 8000
```

### Step 6: Access Application
Open browser: http://localhost:8000

## What You Get

✅ **Django 4.2** web application  
✅ **Document Templates** management system  
✅ **Document Generation** wizard  
✅ **Version Control** for documents  
✅ **Activity Logging** and audit trail  
✅ **Admin Interface** for management  
✅ **Export Options** (HTML, PDF, DOCX)  
✅ **Automatic URL Configuration** - ready to use  
✅ **Static Files** configured with WhiteNoise  

## Next Steps

1. **Create Templates**: Access /admin and add document templates
2. **Generate Documents**: Use the wizard at /forge/ to create documents
3. **Configure Production**: See docs/IIS-Setup.md for IIS deployment
4. **Customize**: Edit templates and styles in the forge app

**Note**: URLs are automatically configured during deployment - just access http://localhost:8000 and you'll be redirected to the BMAD Forge homepage!

## Need Help?

- 📖 Full Documentation: `docs/README.md`
- 🔧 Troubleshooting: `docs/Troubleshooting.md`  
- 🚀 IIS Setup: `docs/IIS-Setup.md`
- 📋 File List: `docs/MANIFEST.md`

## System Requirements

- Windows 10/11 or Server 2019/2022
- Python 3.13
- 4GB RAM minimum
- 500MB disk space

## Support

Check logs at: `C:\inetpub\bmad-forge\logs\django.log`
