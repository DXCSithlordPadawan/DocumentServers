"""
BMAD Forge Admin Configuration
"""
from django.contrib import admin
from django.utils.html import format_html
from .models import DocumentTemplate, GeneratedDocument, DocumentActivity


@admin.register(DocumentTemplate)
class DocumentTemplateAdmin(admin.ModelAdmin):
    """
    Admin interface for DocumentTemplate
    """
    list_display = ['name', 'document_type', 'is_active', 'created_at', 'updated_at', 'documents_count']
    list_filter = ['document_type', 'is_active', 'created_at']
    search_fields = ['name', 'description']
    readonly_fields = ['created_at', 'updated_at', 'created_by']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'document_type', 'description', 'is_active')
        }),
        ('Template Content', {
            'fields': ('template_content', 'css_content', 'js_content', 'template_variables'),
            'classes': ('wide',)
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at', 'created_by'),
            'classes': ('collapse',)
        }),
    )
    
    def documents_count(self, obj):
        """Display count of documents generated from this template"""
        count = obj.generated_documents.count()
        return format_html('<strong>{}</strong>', count)
    documents_count.short_description = 'Documents'
    
    def save_model(self, request, obj, form, change):
        """Set created_by on creation"""
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(GeneratedDocument)
class GeneratedDocumentAdmin(admin.ModelAdmin):
    """
    Admin interface for GeneratedDocument
    """
    list_display = ['title', 'template', 'status', 'version', 'created_by', 'created_at', 'file_size_display']
    list_filter = ['status', 'template', 'created_at', 'updated_at']
    search_fields = ['title', 'template__name']
    readonly_fields = ['created_at', 'updated_at', 'created_by', 'reviewed_by', 'review_date', 'version']
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Document Information', {
            'fields': ('template', 'title', 'status', 'version', 'parent_document')
        }),
        ('Content', {
            'fields': ('content', 'variables_used'),
            'classes': ('collapse',)
        }),
        ('File Information', {
            'fields': ('file_name', 'file_path', 'file_size'),
            'classes': ('collapse',)
        }),
        ('Metadata', {
            'fields': ('created_at', 'created_by', 'updated_at', 'reviewed_by', 'review_date'),
            'classes': ('collapse',)
        }),
    )
    
    actions = ['approve_documents', 'archive_documents']
    
    def file_size_display(self, obj):
        """Display file size in human-readable format"""
        if obj.file_size:
            size = obj.file_size
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
        return '-'
    file_size_display.short_description = 'File Size'
    
    def approve_documents(self, request, queryset):
        """Bulk approve documents"""
        count = 0
        for doc in queryset:
            doc.approve(request.user)
            count += 1
        self.message_user(request, f'{count} document(s) approved successfully.')
    approve_documents.short_description = 'Approve selected documents'
    
    def archive_documents(self, request, queryset):
        """Bulk archive documents"""
        count = queryset.update(status='archived')
        self.message_user(request, f'{count} document(s) archived successfully.')
    archive_documents.short_description = 'Archive selected documents'


@admin.register(DocumentActivity)
class DocumentActivityAdmin(admin.ModelAdmin):
    """
    Admin interface for DocumentActivity
    """
    list_display = ['document', 'activity_type', 'user', 'timestamp', 'description_short']
    list_filter = ['activity_type', 'timestamp']
    search_fields = ['document__title', 'user__username', 'description']
    readonly_fields = ['document', 'activity_type', 'user', 'timestamp', 'description', 'metadata']
    date_hierarchy = 'timestamp'
    
    def description_short(self, obj):
        """Display truncated description"""
        if len(obj.description) > 50:
            return obj.description[:50] + '...'
        return obj.description
    description_short.short_description = 'Description'
    
    def has_add_permission(self, request):
        """Disable manual creation of activity logs"""
        return False
    
    def has_change_permission(self, request, obj=None):
        """Make activity logs read-only"""
        return False
    
    def has_delete_permission(self, request, obj=None):
        """Prevent deletion of activity logs"""
        return False
