"""
BMAD Forge Views
Views for document generation and management
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from django.db.models import Q

from .models import DocumentTemplate, GeneratedDocument, DocumentActivity
from .forms import DocumentTemplateForm, GenerateDocumentForm
from .document_generator import DocumentGenerator

import json
import logging

logger = logging.getLogger(__name__)


def index(request):
    """
    Homepage view
    """
    recent_documents = GeneratedDocument.objects.filter(
        status__in=['draft', 'review', 'approved']
    )[:5]
    
    template_count = DocumentTemplate.objects.filter(is_active=True).count()
    document_count = GeneratedDocument.objects.count()
    
    context = {
        'recent_documents': recent_documents,
        'template_count': template_count,
        'document_count': document_count,
    }
    
    return render(request, 'forge/index.html', context)


def template_list(request):
    """
    List all active document templates
    """
    templates = DocumentTemplate.objects.filter(is_active=True)
    
    # Filter by document type if specified
    doc_type = request.GET.get('type')
    if doc_type:
        templates = templates.filter(document_type=doc_type)
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        templates = templates.filter(
            Q(name__icontains=search) | Q(description__icontains=search)
        )
    
    context = {
        'templates': templates,
        'document_types': DocumentTemplate.DOCUMENT_TYPES,
        'current_type': doc_type,
        'search_query': search,
    }
    
    return render(request, 'forge/template_list.html', context)


def template_detail(request, template_id):
    """
    View template details
    """
    template = get_object_or_404(DocumentTemplate, id=template_id)
    
    # Get recent documents generated from this template
    recent_docs = template.generated_documents.all()[:10]
    
    context = {
        'template': template,
        'recent_documents': recent_docs,
        'variables': template.get_variables(),
    }
    
    return render(request, 'forge/template_detail.html', context)


@login_required
def generate_document(request, template_id):
    """
    Generate a document from a template using wizard interface
    """
    template = get_object_or_404(DocumentTemplate, id=template_id)
    
    if request.method == 'POST':
        form = GenerateDocumentForm(request.POST, template=template)
        
        if form.is_valid():
            try:
                # Get form data
                title = form.cleaned_data['title']
                variables = form.get_variables()
                
                # Generate document
                generator = DocumentGenerator(template)
                content = generator.generate(variables)
                
                # Create document record
                document = GeneratedDocument.objects.create(
                    template=template,
                    title=title,
                    content=content,
                    created_by=request.user,
                    status='draft'
                )
                document.set_variables(variables)
                document.save()
                
                # Log activity
                DocumentActivity.objects.create(
                    document=document,
                    activity_type='created',
                    description=f"Document created from template: {template.name}",
                    user=request.user
                )
                
                messages.success(request, f"Document '{title}' generated successfully!")
                return redirect('forge:document_detail', document_id=document.id)
                
            except Exception as e:
                logger.error(f"Document generation failed: {str(e)}")
                messages.error(request, f"Document generation failed: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = GenerateDocumentForm(template=template)
    
    context = {
        'template': template,
        'form': form,
        'variables': template.get_variables(),
    }
    
    return render(request, 'forge/generate_document_wizard.html', context)


def document_list(request):
    """
    List generated documents with filtering
    """
    documents = GeneratedDocument.objects.select_related('template', 'created_by')
    
    # Filter by status
    status = request.GET.get('status')
    if status:
        documents = documents.filter(status=status)
    
    # Filter by template
    template_id = request.GET.get('template')
    if template_id:
        documents = documents.filter(template_id=template_id)
    
    # Search
    search = request.GET.get('search')
    if search:
        documents = documents.filter(
            Q(title__icontains=search) | 
            Q(template__name__icontains=search)
        )
    
    context = {
        'documents': documents,
        'status_choices': GeneratedDocument.STATUS_CHOICES,
        'current_status': status,
        'search_query': search,
    }
    
    return render(request, 'forge/document_list.html', context)


def document_detail(request, document_id):
    """
    View document details and preview
    """
    document = get_object_or_404(
        GeneratedDocument.objects.select_related('template', 'created_by', 'reviewed_by'),
        id=document_id
    )
    
    # Get document activity history
    activities = document.activities.select_related('user')[:20]
    
    # Get document versions
    if document.parent_document:
        versions = document.parent_document.versions.all()
    else:
        versions = document.versions.all()
    
    context = {
        'document': document,
        'activities': activities,
        'versions': versions,
        'variables': document.get_variables(),
    }
    
    return render(request, 'forge/document_detail.html', context)


@login_required
@require_http_methods(["POST"])
def document_approve(request, document_id):
    """
    Approve a document
    """
    document = get_object_or_404(GeneratedDocument, id=document_id)
    
    try:
        document.approve(request.user)
        
        DocumentActivity.objects.create(
            document=document,
            activity_type='approved',
            description=f"Document approved by {request.user.get_full_name() or request.user.username}",
            user=request.user
        )
        
        messages.success(request, f"Document '{document.title}' approved successfully!")
    except Exception as e:
        logger.error(f"Document approval failed: {str(e)}")
        messages.error(request, f"Approval failed: {str(e)}")
    
    return redirect('forge:document_detail', document_id=document.id)


@login_required
def document_download(request, document_id, format='html'):
    """
    Download document in specified format
    """
    document = get_object_or_404(GeneratedDocument, id=document_id)
    
    # Log download activity
    DocumentActivity.objects.create(
        document=document,
        activity_type='downloaded',
        description=f"Document downloaded in {format.upper()} format",
        user=request.user
    )
    
    if format == 'html':
        response = HttpResponse(document.content, content_type='text/html')
        response['Content-Disposition'] = f'attachment; filename="{document.file_name or document.title}.html"'
        return response
    
    elif format == 'pdf':
        # PDF generation would require additional library (e.g., weasyprint, reportlab)
        messages.warning(request, "PDF export not yet implemented")
        return redirect('forge:document_detail', document_id=document.id)
    
    elif format == 'docx':
        # DOCX generation would require python-docx
        messages.warning(request, "DOCX export not yet implemented")
        return redirect('forge:document_detail', document_id=document.id)
    
    else:
        messages.error(request, f"Unsupported format: {format}")
        return redirect('forge:document_detail', document_id=document.id)


@require_http_methods(["GET"])
def api_template_variables(request, template_id):
    """
    API endpoint to get template variables
    """
    template = get_object_or_404(DocumentTemplate, id=template_id)
    
    return JsonResponse({
        'success': True,
        'template_id': template.id,
        'template_name': template.name,
        'variables': template.get_variables()
    })


@require_http_methods(["POST"])
def api_validate_document(request):
    """
    API endpoint to validate document data before generation
    """
    try:
        data = json.loads(request.body)
        template_id = data.get('template_id')
        variables = data.get('variables', {})
        
        template = get_object_or_404(DocumentTemplate, id=template_id)
        required_vars = template.get_variables()
        
        # Validate required variables
        missing = []
        for var_name, var_config in required_vars.items():
            if var_config.get('required', False) and not variables.get(var_name):
                missing.append(var_name)
        
        if missing:
            return JsonResponse({
                'success': False,
                'errors': {
                    'missing_variables': missing
                }
            }, status=400)
        
        return JsonResponse({
            'success': True,
            'message': 'Validation passed'
        })
        
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)
