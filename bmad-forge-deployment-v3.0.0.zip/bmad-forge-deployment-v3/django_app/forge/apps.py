"""
Django app configuration for BMAD Forge
"""
from django.apps import AppConfig


class ForgeConfig(AppConfig):
    """Configuration for the forge application"""
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'forge'
    verbose_name = 'BMAD Forge Document Generator'
    
    def ready(self):
        """
        Import signal handlers when app is ready
        """
        # Import signals here if needed
        pass
