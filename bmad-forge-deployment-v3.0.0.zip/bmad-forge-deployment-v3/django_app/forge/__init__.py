"""
BMAD Forge Django Application
Document generation and management system
"""

default_app_config = 'forge.apps.ForgeConfig'
